create definer = root@localhost trigger del_film
    after delete
    on film
    for each row
BEGIN
    DELETE FROM film_text WHERE film_id = old.film_id;
  END;

